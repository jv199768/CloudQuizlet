## Split boto3.resources into several modules ##
