
.. include:: ../README.rst

Documentation:

.. toctree::
   :maxdepth: 1

   API Documentation <api>
   FAQs <faq>
   Release News  <news>


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

