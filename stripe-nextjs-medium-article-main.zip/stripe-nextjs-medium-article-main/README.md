This repo is part of a [Medium](https://blog.elisv.com/how-to-add-stripe-payments-to-your-next-js-app-d1cfced7c8a5) article i wrote about setting up stripe with nextjs 13.4
