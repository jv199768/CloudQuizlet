# Sample Lambda function demonstrating the use of environment variables
import os

def lambda_handler(event, context):
    # Access an environment variable
    my_secret = os.environ['AWS_ACCESS_KEY_ID']
    print("Accessing My Secret Key: ", my_secret)
    # Your function logic here
    return {
        'my_secret': my_secret
    }
