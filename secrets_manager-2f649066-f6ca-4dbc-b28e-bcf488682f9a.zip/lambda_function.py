import boto3
import json

def lambda_handler(event, context):
    # TODO implement
    client = boto3.client('secretsmanager')
    get_secret_value_response = client.get_secret_value(SecretId='openAiKey')
    secret = get_secret_value_response['SecretString']
    return {
        'statusCode': 200,
        'body': json.dumps(secret)
    }
