const { GoogleGenerativeAI } = require("@google/generative-ai");
require('dotenv').config()
const fs = require('fs')
const model = genAI.getGenerativeModel({model: "gemini-pro-vision"});

// Access your API key as an environment variable (see "Set up your API key" above)

const genAI = new GoogleGenerativeAI(process.env.API_KEY)



console.log(model)

async function run() {
   // const model = genAI.getGenerativeModel({ model: "gemini-pro"});
    const model = genAI.getGenerativeModel({model: "gemini-pro-vision"});
    const prompt = "What's different between these fingerprints?"
    const imageParts = [
        filetoGenerativePart("fingerprint-scaled.jpg", "image/jpg"),
        filetoGenerativePart("gettingresults_fingerprint.png", "image/png")
    ]
    const result = await model.generateContent([prompt, ...imageParts])
    const response = await result.response
    const text = response.text()
    console.log(text)

}

function filetoGenerativePart(path, mimeType){

    return {
        inlineData: {
            data: ArrayBuffer.from(fs.readFileSync(path)).toString('base64'), 
            mimeType
        }
    }
}

run()